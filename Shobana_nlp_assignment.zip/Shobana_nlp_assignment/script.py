#!/usr/bin/env python
# coding: utf-8

# In[1]:


import PyPDF2
import re
import random
from string import ascii_lowercase


# In[2]:


def extract_text_from_pdf(pdf_path):
    """
    Extracts text from a PDF file.
    """
    text = ""
    with open(pdf_path, "rb") as file:
        reader = PyPDF2.PdfReader(file)
        num_pages = len(reader.pages)
        for page_num in range(num_pages):
            page = reader.pages[page_num]
            text += page.extract_text()
    return text


# In[3]:


def remove_dates_times(text):
    """
    Removes dates and times from the given text.
    """
    # using regex patterns for date and time formats
    date_pattern = r"\b\d{1,2}[/\-]\d{1,2}[/\-]\d{2,4}\b"  # Matches dates in formats like dd/mm/yyyy or dd-mm-yyyy
    time_pattern = r"\b\d{1,2}:\d{2}(:\d{2})?\s*(AM|PM)?\b"  # Matches times in formats like hh:mm:ss AM/PM or hh:mm AM/PM

    # Removing date and time patterns from the text
    text_without_dates = re.sub(date_pattern, "", text)
    text_without_dates_times = re.sub(time_pattern, "", text_without_dates)

    return text_without_dates_times


# In[4]:



def clean_text(text):
    """
    Cleans the text by removing unwanted characters and extra whitespaces.
    """
    cleaned_text = re.sub(r'\s+', ' ', text)
    cleaned_text = re.sub(r'\r', ' ', cleaned_text)
    cleaned_text = re.sub(r'\n', ' ', cleaned_text)
    cleaned_text = re.sub(r'\[.*?\]', '', cleaned_text)
    cleaned_text = re.sub(r'\(.*?\)', '', cleaned_text)
    cleaned_text = cleaned_text.strip()
    return cleaned_text


# In[5]:


def generate_multiple_choice_question(question, options, correct_options):
    """
    Generates a multiple-choice question with the provided question, options, and correct options.
    """
    choices = [f"{option}. {text}" for option, text in zip(ascii_lowercase, options)]
    correct_choices = [option for option, is_correct in zip(ascii_lowercase, correct_options) if is_correct]
    correct_choices_formatted = " & ".join(correct_choices)
    question_with_choices = question + "\n" + "\n".join(choices) + "\nCorrect Options: (" + correct_choices_formatted + ")"

    return question_with_choices


# In[6]:


def get_mca_questions(context):
    """
    Generates multiple-choice questions based on the provided context.
    """
    entities = context.split(",")
    entity_counts = {}
    
    for entity in entities:
        entity = entity.strip()
        if entity:
            entity_counts[entity] = entity_counts.get(entity, 0) + 1
    
    mca_questions = []
    question_count = 1
    
    for entity in entity_counts:
        # Filter out entities that occur less than a certain threshold
        if entity_counts[entity] < 2:
            continue
        
        question = f"Q{question_count}: Which of the following are related to {entity}? Choose two options."
        options = [entity]
        
        # Add two random distractors
        distractors = list(entity_counts.keys())
        distractors.remove(entity)
        random.shuffle(distractors)
        options.extend(distractors[:2])
        
        # Randomly assign correct options
        correct_options = [True, False, False, False]
        random.shuffle(correct_options)
        
        question_formatted = generate_multiple_choice_question(question, options, correct_options)
        mca_questions.append(question_formatted)
        
        question_count += 1
    
    return mca_questions


# In[11]:


# Provide the path to your PDF file
pdf_file_path = "chapter-2.pdf"

# Call the function to extract text from the PDF
extracted_text = extract_text_from_pdf(pdf_file_path)

# Remove dates and times from the extracted text
cleaned_text = remove_dates_times(extracted_text)

# Clean the text by removing unwanted characters and whitespaces
cleaned_text = clean_text(cleaned_text)

# Generate multiple-choice questions based on the cleaned text
mca_questions = get_mca_questions(cleaned_text)

# Print the generated multiple-choice questions
for question in mca_questions:
    print(question)


# In[12]:


import csv

# Specify the path to the output CSV file
csv_file_path = "objective1.csv"

# Write the questions to the CSV file
with open(csv_file_path, "w", newline="") as file:
    writer = csv.writer(file)
    writer.writerow(["Question"])
    for question in mca_questions:
        writer.writerow([question])

print(f"Questions saved to {csv_file_path}")


# In[ ]:




